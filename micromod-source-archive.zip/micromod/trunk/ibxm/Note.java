
package ibxm;

public class Note {
	public int key, instrument, volume, effect, param;
}
